# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 14:18:20 2019

@author: raghaw
"""

import socket
import ssl
import sslpsk
from httplib import HTTPResponse
from StringIO import StringIO

class FakeSocket():
	def __init__(self, response_str):
		self._file = StringIO(response_str)
	def makefile(self, *args, **kwargs):
		return self._file

class CreateConnection:
    def __init__(self, host, port, pskId, pskKey):
        self.host = host
        self.port = port
        self.pskId = pskId
        self.pskKey = pskKey
    
    def getSocket(self):
        sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((self.host, self.port))
        sock = sslpsk.wrap_socket(sock, psk=(self.pskKey.decode('hex'), self.pskId), ssl_version=ssl.PROTOCOL_TLSv1_2,
                                        ciphers='PSK-AES256-CBC-SHA:PSK-AES256-CBC-SHA384')
        return sock
    
    def setRequestsData(self, sock, headers, payload=None):
        for key, value in headers.items():
            sock.write(key+": "+value+"\r\n")
        if payload != None:
            sock.write("Content-Length: "+str(len(payload))+"\r\n")
            sock.write("\r\n")
            sock.write(payload+"\r\n")
        else:
            sock.write("\r\n")
        return sock
    
    def parseResponse(self, response):
        source = FakeSocket(response)
        response = HTTPResponse(source)
        response.begin()
        print("Response Status : "+str(response.status))
        header = {a[0]:a[1] for a in response.getheaders()}
        content = response.read()
        response.close()
        return header, content
    
    def get(self, url, headers):
        sock = self.getSocket()
        sock.write("GET "+url+" HTTP/1.1\r\n")
        sock = self.setRequestsData(sock, headers)
        response = sock.read(len=4096)
        sock.close()
        return self.parseResponse(response)
        
    def post(self, url, headers, payload):
        sock = self.getSocket()
        sock.write("POST "+url+" HTTP/1.1\r\n")
        sock = self.setRequestsData(sock, headers, payload)
        response = sock.read(len=4096)
        print(response)
        sock.close()
        return self.parseResponse(response)
    
    def put(self, url, headers, payload):
        sock = self.getSocket()
        sock.write("PUT "+url+" HTTP/1.1\r\n")
        sock = self.setRequestsData(sock, headers, payload)
        response = sock.read(len=4096)
        sock.close()
        return self.parseResponse(response)
    
    def delete(self, url, headers):
        sock = self.getSocket()
        sock.write("DELETE "+url+" HTTP/1.1\r\n")
        sock = self.setRequestsData(sock, headers)
        response = sock.read(len=4096)
        sock.close()
        return self.parseResponse(response)
    
    
    
    