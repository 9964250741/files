#from server side
#those who wants to receive the notification should create subscription
import random,os,ast,json
import random
from CreateSslConnection import CreateConnection
compName = "PYROX"
adnaeId = "S0052"
adnNo = "CSE001"
pskid = "3171EE07E47785A1F8073D423A579673@cdot.in"
pskKey = "BC5F1488430CC32A5C4CB2D6FFFA2E33FB665B09BF1567F957A2E0358CAE9818"
path="/var/www/html/onem2m/file2/one_m2m_serverside/config/config.json"
temp="/var/www/html/onem2m/file2/one_m2m_serverside/config/temp.json" #temporary file
url = 'http://196.1.111.16'

def getrand():
    a = ''.join([random.choice('0123456789abcdef') for _ in range(8)])
    b = ''.join([random.choice('0123456789abcdef') for _ in range(4)])
    c = ''.join([random.choice('0123456789abcdef') for _ in range(4)])
    d = ''.join([random.choice('0123456789abcdef') for _ in range(4)])
    e = ''.join([random.choice('0123456789abcdef') for _ in range(12)])
    return a+'-'+b+'-'+c+'-'+d+'-'+e



# Uncomment which one you will be using
cc = CreateConnection("196.1.111.16", 9093, pskid, pskKey)
#cc = CreateConnection("192.168.46.2", 9091, lmcpskId, lmcpskKey)


headers = {'X-M2M-Origin': "S0052", 'Content-Type':'application/json;ty=23', 'X-M2M-RI':getrand(),'Cache-Control':'no-cache', 'Accept':'application/json'}
payload = {"m2m:sub":{"rn":["sub_PYROX_device_status"],"enc":{"net":[3]},"nu":["S0052","18.216.220.165:8080"],"nct":1}}                                                                                                                            4444"],"nct":1}}'

with open(path, "r+") as f:
    x = json.load(f)
    # print(type(x))
    c = ast.literal_eval(x)

rh, rc = cc.post(url+"/"+c["device_status_RID"], headers, payload)
print("###################################### Response Header #######################################")
print(rh)
print("##############################################################################################")
with open(temp, "w") as x:
    json.dump(rc, x)

with open(temp, "r+") as a:
    b = json.load(a)
    r = json.loads(b)
    c = ast.literal_eval(json.dumps(r))
    for i in c:
        for j in c[i]:
            if j == 'ri':
                x = c[i][j]
                x = str(c[i][j])
                y = "device_status_sub_RID"

                device_status_sub_RID = {y: x}

print(device_status_sub_RID)
os.remove(temp)
try:

    if (os.path.exists(path)):  # if a json file exists

        with open(path, "r+") as f:
            x = json.load(f)
            # print(x)
            # print(type(x))
            c = ast.literal_eval(x)  # print(c)
            # print(type(c))

            c.update(device_status_sub_RID)  # merge the new ID with the content
            # print(c)
            # c=str(c)
            # f.close()
            with open(path, "r+") as f:
                c = str(c)
                json.dump(c, f)  # store the updated contents in the file
# else:
#     with open('newjson.json',"w") as f:          #if no file exist create
#         device_container_RID=str(device_container_RID)
#         json.dump(device_container_RID,f) #STORE THE VALUE

except:

    print("completed")
